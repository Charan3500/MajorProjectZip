export class doctor{


    
        "doctorID": number|null;
        "doctorName": string
        "doctorPhoneNumber": string
        "doctorDepartment": string
        "doctorSpecialization": string
        "doctorEmail": string
        "username": string
        "password": string



        constructor()
{
    this.doctorID=null;
    this.doctorName="";
    this.doctorPhoneNumber="";
    this.doctorDepartment="";
    this.doctorSpecialization="";
    this.doctorEmail="";
    this.username="";
    this.password="";
    

}


}
